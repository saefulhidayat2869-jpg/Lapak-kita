# LapakKita — Website marketplace demo

## Isi paket
- `index.html`: website responsif untuk HP dan desktop.
- `manifest.json` dan `sw.js`: dasar agar website bisa dijadikan PWA setelah di-host lewat HTTPS.

## Fitur demo
- Cari produk dan filter kategori.
- Form pasang iklan.
- Simpan iklan di browser lokal.
- Tombol chat penjual melalui WhatsApp.
- Desain responsif untuk HP.

## Penting
Ini masih DEMO frontend. Iklan pengguna disimpan di browser perangkat yang membuatnya; belum tersinkron ke pengguna lain. Produk bertanda CONTOH adalah data dummy. Jangan menganggap nomor WhatsApp pada produk contoh sebagai penjual nyata.

## Cara menerbitkan gratis dari HP
1. Ekstrak ZIP ini.
2. Buat akun GitHub jika belum punya.
3. Buat repository baru bernama `lapakkita`.
4. Unggah `index.html`, `manifest.json`, dan `sw.js` ke repository.
5. Buka Settings > Pages, pilih deploy from branch `main` dan folder `/ (root)`, lalu simpan.
6. Tunggu sampai GitHub Pages memberi alamat website. Buka alamat itu dari Chrome Android.
7. Untuk membuat ikon aplikasi, menampilkan iklan semua pengguna, dan mengelola data secara sungguhan, tahap berikutnya perlu database online (misalnya Supabase) dan autentikasi serta aturan keamanan.

## Catatan keamanan
Jangan mengumpulkan kata sandi, PIN, atau OTP dalam formulir. Sebelum mengaktifkan transaksi berbayar, perlu desain keamanan, moderasi iklan, pelaporan penipuan, kebijakan privasi, dan ketentuan penggunaan.
